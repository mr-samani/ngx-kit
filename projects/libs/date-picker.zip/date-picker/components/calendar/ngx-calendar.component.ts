import {
  AfterViewInit,
  Component,
  ElementRef,
  EventEmitter,
  HostListener,
  inject,
  input,
  Input,
  OnInit,
  Output,
  viewChild,
} from '@angular/core';
import { NgxDatePickerConfig } from '../config';
import { NgxDatePickerBase } from '../ngx-date-picker-base.component';
import { MsEvents } from '../../models/events';
import { CalendarView } from '../../models/view';
import { ISelectedEvent } from '../../models/selected-event';
import { CommonModule } from '@angular/common';
import { compareDate, deserialize, sameDate } from '../../helpers/date.helper';
import { DateAdapterRegistry } from '../../adapters/date-adapter-registry';
import { DateViewDay } from '../../models/date';
import { MsEventViewer } from '../../models/events';
import { NGX_CALENDAR_LOCALIZATION, NgxCalendarLocalization } from '../../tokens/localization';
@Component({
  selector: 'ngx-calendar',
  templateUrl: './ngx-calendar.component.html',
  styleUrls: ['./ngx-calendar.component.scss'],
  imports: [CommonModule],
  providers: [DateAdapterRegistry],
})
export class NgxCalendarComponent extends NgxDatePickerBase implements OnInit, AfterViewInit {
  defaultLocalization = inject(NGX_CALENDAR_LOCALIZATION);
  localize = input<NgxCalendarLocalization>(this.defaultLocalization);
  _config = new NgxDatePickerConfig();
  @Input() set config(val: NgxDatePickerConfig) {
    this._config = { ...new NgxDatePickerConfig(), ...val };
  }
  @Input() set locale(val: string) {
    this._locale = val;
    this.adapter = this.dateAdapterRegistry.resolve(this._locale);
    this.ngOnInit();
  }
  /** The minimum valid date. */
  @Input('min') set setMin(value: Date | null | undefined) {
    const validValue = deserialize(value);
    if (!sameDate(validValue, this.minDate)) {
      this.minDate = validValue;
    }
  }

  /** The maximum valid date. */
  @Input('max') set setMax(value: Date | null | undefined) {
    const validValue = deserialize(value);
    if (!sameDate(validValue, this.maxDate)) {
      this.maxDate = validValue;
    }
  }

  @Input() view: CalendarView = 'month';
  _events: MsEvents[] = [];
  eventViewItems: { event: MsEventViewer; start: Date; end: Date }[] = [];

  @Input() set events(val: MsEvents[]) {
    this._events = Array.isArray(val) ? val : [];
    // Keep the calendar reactive when events are loaded asynchronously.
    if (this.currYear !== undefined && this.currMonth !== undefined) {
      this.renderCalendar(this.view);
    }
  }

  @Output() dateChange = new EventEmitter<DateViewDay>();
  @Output() selectEvent = new EventEmitter<ISelectedEvent>();

  defaultHeight = 600;
  minHeight = this.defaultHeight;

  selected?: Date;

  calendarWrapper = viewChild<ElementRef<HTMLElement>>('calendarWrapper');
  constructor() {
    super();
  }

  ngOnInit(): void {
    this.months = this.adapter.longMonths;
    this.weeks = this.adapter.longDays;
    if (this.selected) {
      let converted = this.adapter.toLocale(this.selected);
      this.currYear = converted.year;
      this.currMonth = converted.month!;
      this.renderCalendar(this.view);
    } else {
      this.gotoToday();
    }
  }

  ngAfterViewInit(): void {
    this.calcCellSize();
  }

  @HostListener('window:resize', ['$event']) onResize(ev: Event) {
    this.calcCellSize();
  }

  calcCellSize() {
    const fullWidth = this.calendarWrapper()?.nativeElement?.clientWidth ?? 0;
    const cellHeight = fullWidth / 6;
    this.minHeight = fullWidth > this.defaultHeight ? this.defaultHeight : fullWidth;
    if (fullWidth <= 500) {
      this.weeks = this.adapter.shortDays;
    } else if (fullWidth > 500) {
      this.weeks = this.adapter.longDays;
    }
  }
  override renderCalendar(view: CalendarView) {
    super.renderCalendar(view, undefined, this._events, () => {
      if (view === 'event') {
        this.renderEventView();
      }
    });
  }

  private renderEventView() {
    const monthStart = this.adapter.getDate({
      locale: this._locale,
      year: this.currYear,
      month: this.currMonth,
      day: 1,
    });
    const monthEnd = this.adapter.getDate({
      locale: this._locale,
      year: this.currYear,
      month: this.currMonth,
      day: this.adapter.lastDateofMonth(this.currYear, this.currMonth),
    });

    this.eventViewItems = this._events
      .map((event) => {
        const start = event.start instanceof Date ? event.start : new Date(event.start as any);
        const end = event.end
          ? event.end instanceof Date
            ? event.end
            : new Date(event.end as any)
          : start;
        return { event: event as MsEventViewer, start, end };
      })
      .filter(
        ({ start, end }) => compareDate(end, monthStart) >= 0 && compareDate(start, monthEnd) <= 0,
      )
      .sort((a, b) => compareDate(a.start, b.start));
  }

  formatEventDate(date: Date): string {
    return this.adapter.formatDate(this.adapter.toLocale(date), 'd MMMM, yyyy') ?? '';
  }

  changeView(v: CalendarView) {
    this.view = v;
    this.renderCalendar(this.view);
  }

  gotoToday() {
    let today = this.adapter.today();
    this.selected = this.adapter.getDate(today);
    this.currYear = today.year;
    this.currMonth = today.month ?? 1;
    this.changeView(this.view);
  }

  selectDay(ev: Event, item: DateViewDay) {
    ev.stopPropagation();
    if (item.active) {
      this.dateChange.emit(item);
    }
  }

  next() {
    debugger;
    if (this.view === 'month' || this.view == 'event') {
      this.currMonth++;
    } else if (this.view == 'day' || this.view == 'week') {
      this.currentWeek++;
    }
    if (this.currMonth < 0 || this.currMonth > 11) {
      let date = new Date(this.currYear, this.currMonth);
      this.currYear = date.getFullYear();
      this.currMonth = date.getMonth();
    }

    this.renderCalendar(this.view);
  }

  previous() {
    if (this.view === 'month' || this.view == 'event') {
      this.currMonth--;
    } else if (this.view == 'day' || this.view == 'week') {
      this.currentWeek--;
    }
    if (this.currMonth < 0 || this.currMonth > 11) {
      let date = new Date(this.currYear, this.currMonth);
      this.currYear = date.getFullYear();
      this.currMonth = date.getMonth();
    }

    this.renderCalendar(this.view);
  }

  onclickEvent(ev: Event, item: DateViewDay, event: MsEvents) {
    ev.stopPropagation();
    this.selectEvent.emit({
      date: item.date!,
      event,
    });
  }
}
