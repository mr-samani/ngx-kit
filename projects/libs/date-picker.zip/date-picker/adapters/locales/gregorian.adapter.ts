import { genFormatDate } from '../../helpers/date-format.helper';
import { DatePickerView } from '../../models/view';
import { IDateAdapter } from '../IAdapter';
import { CalendarDate } from '../calendar-date';
import type { FormatType } from '../consts';

export class GregorianAdapter implements IDateAdapter {
  startOfWeek = 0;
  weekStartDay = 0;
  get longMonths() {
    return [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];
  }
  get narrowDays() {
    return ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  }
  get shortDays() {
    return ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
  }
  get longDays() {
    return ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  }

  toLocale(date: Date): CalendarDate {
    const d = date;
    return {
      locale: 'en',
      day: d.getDate(),
      month: d.getMonth(),
      year: d.getFullYear(),
      date: d,
      hours: date.getHours(),
      minutes: date.getMinutes(),
      seconds: date.getSeconds(),
      milliseconds: date.getMilliseconds(),
      dayOfWeek: date.getDay(),
    };
  }
  today() {
    return this.toLocale(new Date());
  }

  /**
   *  getting first day of month
   */
  firstDayofMonth(year: number, month: number) {
    return new Date(year, month, 1).getDay();
  }
  /**
   * getting last date of month
   */
  lastDateofMonth(year: number, month: number) {
    return new Date(year, month + 1, 0).getDate();
  }
  /**
   * getting last day of month
   */
  lastDayofMonth(year: number, month: number) {
    return new Date(year, month, this.lastDateofMonth(year, month)).getDay();
  }
  /**
   * getting last date of previous month
   */
  lastDateofLastMonth(year: number, month: number) {
    return new Date(year, month, 0).getDate();
  }

  // TODO
  /**
   * month start with zero
   * @param date
   * @returns
   */
  getDate(date: CalendarDate): Date {
    let str = date.year + '-' + (date.month ? date.month + 1 : 1) + '-' + (date.day ?? 1);
    str = str
      .split('-')
      .map((i) => {
        return i.length < 2 ? '0' + i : i;
      })
      .join('-');
    if (date.hours || date.minutes || date.seconds || date.milliseconds) {
      str +=
        ' ' +
        (date.hours ?? 0) +
        ':' +
        (date.minutes ?? 0) +
        ':' +
        (date.seconds ?? 0) +
        ':' +
        (date.milliseconds ?? 0);
    }
    return new Date(str);
  }

  formatDate(date: CalendarDate, format: FormatType) {
    if (!date) {
      return '';
    }
    // let option: Intl.DateTimeFormatOptions = {
    //     year: 'numeric',
    //     month: '2-digit',
    //     day: '2-digit'
    // };
    // if (format === 'full') {
    //     option = {
    //         year: 'numeric',
    //         month: 'long',
    //         day: '2-digit',
    //         weekday: 'long'
    //     };
    // }
    // return new Date(date).toLocaleDateString('en-US', option);
    return genFormatDate(date, format, this.longMonths, this.longDays);
  }
  getStartOfWeek(date: Date): Date {
    const d = new Date(date);
    d.setHours(0, 0, 0, 0);
    const delta = (d.getDay() - this.weekStartDay + 7) % 7;
    d.setDate(d.getDate() - delta);
    return d;
  }

  getEndOfWeek(date: Date): Date {
    const d = this.getStartOfWeek(date);
    d.setDate(d.getDate() + 6);
    d.setHours(23, 59, 59, 999);
    return d;
  }

  getStartOf(date: Date | null, t: DatePickerView) {
    if (!date) {
      return date;
    }
    switch (t) {
      case 'year':
        return new Date(date.getFullYear(), 0, 1);
      case 'month':
        return new Date(date.getFullYear(), date.getMonth(), 1);
      case 'day':
        return new Date(date.getFullYear(), date.getMonth(), date.getDate());
    }
  }

  getLastOf(date: Date | null, t: DatePickerView) {
    if (!date) {
      return date;
    }
    switch (t) {
      case 'year':
        return new Date(date.getFullYear(), 12, 0);
      case 'month':
        return new Date(date.getFullYear(), date.getMonth() + 1, 0);
      case 'day':
        return new Date(date.getFullYear(), date.getMonth(), date.getDate());
    }
  }
}
